import { NextRequest, NextResponse } from "next/server";
import { ApiError } from "@/lib/errors";
import { fetchYouTubeImage } from "@/lib/download";
import { clientIp, jsonError } from "@/lib/http";
import { rateLimit } from "@/lib/rateLimit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Takes ?id=<11-char YouTube video id>&q=<quality key> — never a raw URL.
 * The actual image URL is built server-side from a fixed host+path pattern
 * (see lib/youtube.ts), so there is nothing here for an SSRF payload to reach:
 * any `u` parameter some old link still sends is simply ignored.
 */
export async function GET(req: NextRequest) {
  const rl = rateLimit(`dl:${clientIp(req)}`, 60, 60_000);
  if (!rl.ok) {
    return jsonError("RATE_LIMITED", "Too many requests. Please try again shortly.", 429, {
      "Retry-After": String(rl.retryAfter),
    });
  }

  try {
    const { bytes, contentType, filename } = await fetchYouTubeImage(
      req.nextUrl.searchParams.get("id"),
      req.nextUrl.searchParams.get("q")
    );
    return new NextResponse(bytes, {
      headers: {
        "Content-Type": contentType,
        "Content-Length": String(bytes.byteLength),
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "private, max-age=3600",
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "default-src 'none'; sandbox",
      },
    });
  } catch (err) {
    if (err instanceof ApiError) return jsonError(err.code, err.message, err.status);
    console.error("[api/download]", err);
    return jsonError("INTERNAL", "We couldn't retrieve a thumbnail from this URL. Try again.", 500);
  }
}
