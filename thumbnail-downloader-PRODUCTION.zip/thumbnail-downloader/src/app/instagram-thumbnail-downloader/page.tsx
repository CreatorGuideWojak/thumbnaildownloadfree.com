import Landing from "@/components/Landing";
import { FAQ } from "@/lib/faq";
import { pageMetadata } from "@/lib/seo";

const path = "/instagram-thumbnail-downloader";

export const metadata = pageMetadata({
  title: "Instagram Thumbnail Downloader - Download Video Thumbnails",
  description: "Preview public Instagram posts and reels using Instagram's own embed. Private content is never accessed, and we never bypass platform protections.",
  absoluteTitle: true,
  path,
});

export default function Page() {
  return (
    <Landing
      path={path}
      crumb="Instagram"
      platform="instagram"
      h1="Instagram Thumbnail Downloader"
      intro="Paste a public post or reel link to preview it. Instagram doesn't currently offer a public way to download the image directly, so we show a genuine preview instead of pretending it works."
      sections={[
        { heading: "What to expect", body: "You'll get a live preview of the post through Instagram's own embed, plus a link to open it on Instagram. There is no download button for Instagram content." },
        { heading: "What we never do", body: "We don't log in, use scrapers, or try to reach private accounts, stories or deleted posts." },
      ]}
      faq={[FAQ[4], FAQ[5], FAQ[6], FAQ[7]]}
    />
  );
}
