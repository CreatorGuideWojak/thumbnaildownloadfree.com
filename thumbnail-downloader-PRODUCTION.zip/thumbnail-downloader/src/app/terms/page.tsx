import { pageMetadata } from "@/lib/seo";
import { site } from "@/lib/site";

export const metadata = pageMetadata({
  title: "Terms of Service",
  description: "Rules for using this thumbnail downloader, including content ownership and acceptable use.",
  path: "/terms",
});

export default function Terms() {
  return (
    <article className="legal py-12">
      <h1 className="text-4xl font-extrabold tracking-tight">Terms of Service</h1>
      <p className="text-muted">Last updated: {site.lastUpdated}</p>

      <h2>The service</h2>
      <p>{site.name} helps you retrieve publicly available YouTube thumbnail images and preview public Instagram posts. We do not host, own or control the content we link to. It is served by the third-party platforms and belongs to its creators.</p>

      <h2>Your responsibility</h2>
      <ul>
        <li>You are responsible for having the right to use anything you download.</li>
        <li>Do not use the service to infringe copyright or others&apos; rights, or to misrepresent content.</li>
        <li>Do not try to access private content, get around access controls, or overload the service with automated requests.</li>
        <li>Follow the terms of the platforms whose content you access.</li>
      </ul>

      <h2>No affiliation</h2>
      <p>We are not affiliated with, endorsed by or sponsored by YouTube, Google, Instagram or Meta. Their names are trademarks of their owners.</p>

      <h2>Availability</h2>
      <p>The service depends on third-party platforms and may change, be limited or stop working without notice. It is provided &ldquo;as is&rdquo; without warranties of any kind.</p>

      <h2>Limitation of liability</h2>
      <p>To the extent permitted by law, we are not liable for indirect or consequential losses arising from use of the service.</p>

      <h2>Changes and contact</h2>
      <p>We may update these terms. Continued use means you accept the changes. Questions: <a href={`mailto:${site.email}`}>{site.email}</a>.</p>
    </article>
  );
}
