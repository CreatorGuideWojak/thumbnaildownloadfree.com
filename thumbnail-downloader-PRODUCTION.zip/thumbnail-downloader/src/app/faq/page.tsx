import FaqList from "@/components/FaqList";
import JsonLd from "@/components/JsonLd";
import { FAQ } from "@/lib/faq";
import { pageMetadata } from "@/lib/seo";

export const metadata = pageMetadata({
  title: "FAQ - ThumbnailDownloadFree",
  description: "Answers about downloading YouTube thumbnails, previewing Instagram posts, supported links, sizes, privacy and usage rights.",
  path: "/faq",
});

export default function FaqPage() {
  return (
    <div className="py-12">
      <h1 className="text-4xl font-extrabold tracking-tight">Frequently asked questions</h1>
      <div className="mt-8"><FaqList items={FAQ} /></div>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQ.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
        }}
      />
    </div>
  );
}
