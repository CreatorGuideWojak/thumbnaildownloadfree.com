import Landing from "@/components/Landing";
import { FAQ } from "@/lib/faq";
import { pageMetadata } from "@/lib/seo";

const path = "/youtube-shorts-thumbnail-downloader";

export const metadata = pageMetadata({
  title: "YouTube Shorts Thumbnail Downloader",
  description: "Download the cover thumbnail from any public YouTube Short in every size YouTube actually generated for it. Free, no sign-up.",
  absoluteTitle: true,
  path,
});

export default function Page() {
  return (
    <Landing
      path={path}
      crumb="YouTube Shorts"
      platform="youtube"
      h1="YouTube Shorts Thumbnail Downloader"
      intro="Paste a youtube.com/shorts/… link and get its cover image. Shorts use the same thumbnail system as regular videos, so sizes and availability work the same way."
      sections={[
        { heading: "Same engine as YouTube videos", body: "Shorts links are parsed the same way as any other YouTube link, so you get the same accurate, checked list of available sizes." },
        { heading: "Vertical video, square-ish files", body: "The thumbnail files themselves are the same fixed pixel sizes YouTube uses for every video; the visible frame inside them reflects the Short's vertical crop." },
      ]}
      faq={[FAQ[0], FAQ[1], FAQ[2], FAQ[3]]}
    />
  );
}
