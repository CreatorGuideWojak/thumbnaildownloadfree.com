import { pageMetadata } from "@/lib/seo";
import { ads, analytics, site } from "@/lib/site";

export const metadata = pageMetadata({
  title: "Privacy Policy",
  description: "What data this thumbnail downloader processes, what it doesn't store, and which optional services are enabled.",
  path: "/privacy",
});

export default function Privacy() {
  const anyAnalytics = Boolean(analytics.plausibleDomain || analytics.gaId);
  return (
    <article className="legal py-12">
      <h1 className="text-4xl font-extrabold tracking-tight">Privacy Policy</h1>
      <p className="text-muted">Last updated: {site.lastUpdated}</p>

      <h2>What we process</h2>
      <p>When you submit a link, our server reads it to find the thumbnail on YouTube or to check whether an Instagram post can be previewed. Links and images are handled in memory and are not saved to a database or file storage. Short-lived in-memory caching may keep lookup results for a few minutes to speed up repeat requests.</p>

      <h2>Technical data</h2>
      <p>Your IP address is used briefly in memory for rate limiting to prevent abuse. Our hosting provider may keep standard server logs (IP address, time, requested path, user agent) for security and operations.</p>

      <h2>Analytics</h2>
      {anyAnalytics ? (
        <p>This site uses {[analytics.plausibleDomain && "Plausible", analytics.gaId && "Google Analytics"].filter(Boolean).join(" and ")} to count visits and events such as &ldquo;thumbnail downloaded&rdquo;. Events include the platform used but never the links you submit.</p>
      ) : (
        <p>This site does not currently use analytics.</p>
      )}

      <h2>Cookies and advertising</h2>
      {ads.client || analytics.gaId ? (
        <p>{ads.client ? "This site shows ads served by Google AdSense, which may use cookies or similar technologies to serve and measure ads. " : ""}{analytics.gaId ? "Google Analytics may also set cookies. " : ""}You can manage cookies in your browser settings.</p>
      ) : (
        <p>This site does not set its own cookies and does not show ads. Embedded Instagram previews are loaded from Instagram and are governed by Instagram&apos;s own policies.</p>
      )}

      <h2>Third parties</h2>
      <p>To fulfil a request we contact YouTube (Google) and, for Instagram links, Meta servers. We do not sell your data.</p>

      <h2>Your rights</h2>
      <p>Because we do not keep personal profiles, there is usually nothing to access or delete. For any privacy request, contact <a href={`mailto:${site.email}`}>{site.email}</a>.</p>

      <h2>Children</h2>
      <p>This service is not directed at children under 13.</p>
    </article>
  );
}
