import { ads } from "@/lib/site";

export const dynamic = "force-static";

/** Serves /ads.txt from NEXT_PUBLIC_ADSENSE_CLIENT. Returns 404 while ads are not configured. */
export function GET() {
  if (!ads.client) return new Response("Not found", { status: 404 });
  const pub = ads.client.replace(/^ca-/, "");
  return new Response(`google.com, ${pub}, DIRECT, f08c47fec0942fa0\n`, {
    headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "public, max-age=3600" },
  });
}
