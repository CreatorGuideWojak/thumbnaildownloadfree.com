import { pageMetadata } from "@/lib/seo";
import { site } from "@/lib/site";

export const metadata = pageMetadata({
  title: "DMCA & Copyright Policy",
  description: "How to report a copyright concern about content accessed through this thumbnail downloader.",
  path: "/dmca",
});

export default function Dmca() {
  return (
    <article className="legal py-12">
      <h1 className="text-4xl font-extrabold tracking-tight">DMCA &amp; Copyright Policy</h1>
      <p className="text-muted">Last updated: {site.lastUpdated}</p>

      <h2>What we host</h2>
      <p>We do not host or own third-party content. Thumbnails are served by YouTube, and Instagram previews are shown by Instagram. Images pass through our server on download without being saved. To have an image removed at its source, contact the platform that hosts it.</p>

      <h2>Report an infringement</h2>
      <p>If you own a copyright and believe this service is being used to infringe it, email <a href={`mailto:${site.email}`}>{site.email}</a> with:</p>
      <ul>
        <li>Your name, address, phone number and email address.</li>
        <li>A description of the copyrighted work.</li>
        <li>The link submitted, or the page on this site, you want reviewed.</li>
        <li>A statement that you believe in good faith the use isn&apos;t authorised by the owner, its agent or the law.</li>
        <li>A statement, under penalty of perjury, that the information is accurate and that you are the owner or authorised to act for the owner.</li>
        <li>Your physical or electronic signature.</li>
      </ul>

      <h2>Counter-notice</h2>
      <p>If you believe a notice was sent in error, contact us with your details, the affected link, and a statement under penalty of perjury that you believe the request was a mistake.</p>

      <h2>Repeat infringers</h2>
      <p>We may block access for users who are repeatedly reported for infringement.</p>
    </article>
  );
}
